package com.example.my_spring_boot_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringBootAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
